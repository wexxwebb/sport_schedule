CREATE FUNCTION "overlaps"(time without time zone, time without time zone, time without time zone, interval)
  RETURNS boolean
IMMUTABLE
COST 1
LANGUAGE SQL
AS $$
select ($1, $2) overlaps ($3, ($3 + $4))
$$;

