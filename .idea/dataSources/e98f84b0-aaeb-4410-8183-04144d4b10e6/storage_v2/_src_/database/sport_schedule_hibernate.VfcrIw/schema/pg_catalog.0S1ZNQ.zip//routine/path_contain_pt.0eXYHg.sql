CREATE FUNCTION path_contain_pt(path, point)
  RETURNS boolean
IMMUTABLE
STRICT
COST 1
LANGUAGE SQL
AS $$
select pg_catalog.on_ppath($2, $1)
$$;

